(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Velociratchet;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/zendy_velociratchet/packages/zendy_velociratchet.js                            //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
(function () {                                                                             // 1
                                                                                           // 2
//////////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                                  //     // 4
// packages/zendy:velociratchet/zendy-velociratchet.js                              //     // 5
//                                                                                  //     // 6
//////////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                    //     // 8
// Namespace for package                                                            // 1   // 9
Velociratchet = {};                                                                 // 2   // 10
                                                                                    // 3   // 11
Velociratchet.history = [];                                                         // 4   // 12
                                                                                    // 5   // 13
Velociratchet.addToHistory = function( routeName ){                                 // 6   // 14
    Velociratchet.history.push( routeName );                                        // 7   // 15
}                                                                                   // 8   // 16
Velociratchet.removeFromHistory = function(){                                       // 9   // 17
    Velociratchet.history.pop();                                                    // 10  // 18
}                                                                                   // 11  // 19
Velociratchet.clearHistory = function() {                                           // 12  // 20
    Velociratchet.history = [];                                                     // 13  // 21
}                                                                                   // 14  // 22
                                                                                    // 15  // 23
// Events for layout template                                                       // 16  // 24
// Add the following to your Meteor app:                                            // 17  // 25
// Template.myLayoutTemplateName.events(Velociratchet.events);                      // 18  // 26
Velociratchet.events = {                                                            // 19  // 27
    'click': function ( evt ) {                                                     // 20  // 28
        Velociratchet.transition = 'vratchet-fade';                                 // 21  // 29
    },                                                                              // 22  // 30
    'click .icon-right-nav': function () {                                          // 23  // 31
        Velociratchet.addToHistory( Router.current().route.getName() );             // 24  // 32
        Velociratchet.transition = 'vratchet-right-to-left';                        // 25  // 33
    },                                                                              // 26  // 34
    'click .navigate-right': function () {                                          // 27  // 35
        Velociratchet.addToHistory( Router.current().route.getName() );             // 28  // 36
        Velociratchet.transition = 'vratchet-right-to-left';                        // 29  // 37
    },                                                                              // 30  // 38
    'click .icon-left-nav': function () {                                           // 31  // 39
        Velociratchet.removeFromHistory();                                          // 32  // 40
        Velociratchet.transition = 'vratchet-left-to-right';                        // 33  // 41
    },                                                                              // 34  // 42
    'click .navigate-left': function () {                                           // 35  // 43
        Velociratchet.removeFromHistory();                                          // 36  // 44
        Velociratchet.transition = 'vratchet-left-to-right';                        // 37  // 45
    },                                                                              // 38  // 46
    'click .toggle': function( event ){                                             // 39  // 47
        var toggle = $(event.target);                                               // 40  // 48
        if( toggle.hasClass( 'active' ) ){                                          // 41  // 49
            toggle.removeClass( 'active' );                                         // 42  // 50
        }else{                                                                      // 43  // 51
            toggle.addClass( 'active' );                                            // 44  // 52
        }                                                                           // 45  // 53
    },                                                                              // 46  // 54
    'click .toggle-handle': function( event ){                                      // 47  // 55
        var toggle = $(event.target).parent();                                      // 48  // 56
        if( toggle.hasClass( 'active' ) ){                                          // 49  // 57
            toggle.removeClass( 'active' );                                         // 50  // 58
        }else{                                                                      // 51  // 59
            toggle.addClass( 'active' );                                            // 52  // 60
        }                                                                           // 53  // 61
    }                                                                               // 54  // 62
                                                                                    // 55  // 63
};                                                                                  // 56  // 64
                                                                                    // 57  // 65
// Helpers for layout template                                                      // 58  // 66
// Add the following to your Meteor app:                                            // 59  // 67
// Template.myLayoutTemplateName.helpers(Velociratchet.helpers);                    // 60  // 68
Velociratchet.helpers = {                                                           // 61  // 69
    transition: function () {                                                       // 62  // 70
        return function (from, to, element) {                                       // 63  // 71
            return Velociratchet.transition || 'vratchet-fade';                     // 64  // 72
        }                                                                           // 65  // 73
    }                                                                               // 66  // 74
};                                                                                  // 67  // 75
                                                                                    // 68  // 76
// Spacebar helpers                                                                 // 69  // 77
if( Meteor.isClient ) {                                                             // 70  // 78
                                                                                    // 71  // 79
    UI.registerHelper('getPreviousPage', function () {                              // 72  // 80
        return Velociratchet.history[Velociratchet.history.length-1];               // 73  // 81
    });                                                                             // 74  // 82
    UI.registerHelper('isActive', function (args) {                                 // 75  // 83
        return args.hash.menu === args.hash.active ? 'active' : '';                 // 76  // 84
    });                                                                             // 77  // 85
    UI.registerHelper('getCurrentRoute', function () {                              // 78  // 86
        return Router.current().route.getName();                                    // 79  // 87
    });                                                                             // 80  // 88
    // XXX: make this a plugin itself?                                              // 81  // 89
    var sideToSide = function(fromX, toX) {                                         // 82  // 90
        return function(options) {                                                  // 83  // 91
            options = _.extend({                                                    // 84  // 92
                duration: 500,                                                      // 85  // 93
                easing: 'ease-in-out'                                               // 86  // 94
            }, options);                                                            // 87  // 95
                                                                                    // 88  // 96
            return {                                                                // 89  // 97
                insertElement: function(node, next, done) {                         // 90  // 98
                    var $node = $(node);                                            // 91  // 99
                                                                                    // 92  // 100
                    $node                                                           // 93  // 101
                        .css('transform', 'translateX(' + fromX + ')')              // 94  // 102
                        .insertBefore(next)                                         // 95  // 103
                        .velocity({                                                 // 96  // 104
                            translateX: [0, fromX]                                  // 97  // 105
                        }, {                                                        // 98  // 106
                            easing: options.easing,                                 // 99  // 107
                            duration: options.duration,                             // 100
                            queue: false,                                           // 101
                            complete: function() {                                  // 102
                                $node.css('transform', '');                         // 103
                                done();                                             // 104
                            }                                                       // 105
                        });                                                         // 106
                },                                                                  // 107
                removeElement: function(node, done) {                               // 108
                    var $node = $(node);                                            // 109
                                                                                    // 110
                    $node                                                           // 111
                        .velocity({                                                 // 112
                            translateX: [toX]                                       // 113
                        }, {                                                        // 114
                            duration: options.duration,                             // 115
                            easing: options.easing,                                 // 116
                            complete: function() {                                  // 117
                                $node.remove();                                     // 118
                                done();                                             // 119
                            }                                                       // 120
                        });                                                         // 121
                }                                                                   // 122
            }                                                                       // 123
        }                                                                           // 124
    }                                                                               // 125
    Momentum.registerPlugin('vratchet-right-to-left', sideToSide('100%', '-100%')); // 126
    Momentum.registerPlugin('vratchet-left-to-right', sideToSide('-100%', '100%')); // 127
    Momentum.registerPlugin('vratchet-fade', function(options) {                    // 128
        Velociratchet.clearHistory();                                               // 129
        return {                                                                    // 130
            insertElement: function(node, next) {                                   // 131
                $(node)                                                             // 132
                    .hide()                                                         // 133
                    .insertBefore(next)                                             // 134
                    .velocity('fadeIn');                                            // 135
            },                                                                      // 136
            removeElement: function(node) {                                         // 137
                $(node).velocity('fadeOut', function() {                            // 138
                    $(this).remove();                                               // 139
                });                                                                 // 140
            }                                                                       // 141
        }                                                                           // 142
    });                                                                             // 143
}                                                                                   // 144
                                                                                    // 145
//////////////////////////////////////////////////////////////////////////////////////     // 154
                                                                                           // 155
}).call(this);                                                                             // 156
                                                                                           // 157
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zendy:velociratchet'] = {
  Velociratchet: Velociratchet
};

})();

//# sourceMappingURL=zendy_velociratchet.js.map
