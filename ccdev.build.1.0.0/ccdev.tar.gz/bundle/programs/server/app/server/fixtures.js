(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Cafes.find().count() === 0) {                                      // 1
	Cafes.insert({                                                        // 2
		name: 'Little Fish Coffee Co.',                                      // 3
		placeid: 'ChIJfSJxVGUGB3wRU-rWruQw_do',                              // 4
		phone: '(808) 335-5000',                                             // 5
		hours: {                                                             // 6
			mon: '6:30 AM - 5:00 PM',                                           // 7
			tue: '6:30 AM - 5:00 PM',                                           // 8
			wed: '6:30 AM - 5:00 PM',                                           // 9
			thu: '6:30 AM - 5:00 PM',                                           // 10
			fri: '6:30 AM - 5:00 PM',                                           // 11
			sat: '6:30 AM - 5:00 PM',                                           // 12
			sun: '8:00 AM - 3:00 PM'                                            // 13
		},                                                                   //
		streetAddress: '3900 Hanapepe Rd',                                   // 15
		city: 'Hanapepe',                                                    // 16
		state: 'Hawaii',                                                     // 17
		zip: '96716',                                                        // 18
		description: 'Little Fish coffee offer great espresso and pastries. The atmosphere is airy and charming. Make sure you have time to sit down and sip up because there’s a gem of a garden, a cool oasis on a typical hot West Side day, hidden in the back of the store. Enjoy!',
		csimage: '/img/little-fish.jpg',                                     // 20
		lat: '21.911201',                                                    // 21
		lng: '-159.586197'                                                   // 22
	});                                                                   //
	Cafes.insert({                                                        // 24
		name: 'Kalaheo Cafe & Coffee Company',                               // 25
		placeid: 'ChIJfzUUJfgEB3wR994OrXg7kEY',                              // 26
		phone: '(808) 332-5858',                                             // 27
		hours: {                                                             // 28
			mon: '6:30 AM - 2:30 PM',                                           // 29
			tue: '6:30 AM - 2:30 PM, 5:00 - 8:30 PM',                           // 30
			wed: '6:30 AM - 2:30 PM, 5:00 - 8:30 PM',                           // 31
			thu: '6:30 AM - 2:30 PM',                                           // 32
			fri: '6:30 AM - 2:30 PM, 5:00 - 9:00 PM',                           // 33
			sat: '6:30 AM - 2:30 PM, 5:00 - 9:00 PM',                           // 34
			sun: '6:30 AM - 2:00 PM'                                            // 35
		},                                                                   //
		streetAddress: '2-2560 Kaumualii Hwy',                               // 37
		city: 'Kalaheo',                                                     // 38
		state: 'Hawaii',                                                     // 39
		zip: '96741',                                                        // 40
		description: 'Whenever we’re heading through Kalaheo, we try to make the time for a stop at Kalaheo Cafe.  The food is great and the atmosphere is relaxed.',
		csimage: '/img/kalaheo-cafe.jpg',                                    // 42
		lat: '21.924843',                                                    // 43
		lng: '-159.523880'                                                   // 44
	});                                                                   //
	Cafes.insert({                                                        // 46
		name: 'Kauai Coffee Company',                                        // 47
		placeid: 'ChIJURsfO8MFB3wReNXq-qP5yaU',                              // 48
		phone: '(808) 335-0813',                                             // 49
		hours: {                                                             // 50
			mon: '9:00 AM - 5:00 PM',                                           // 51
			tue: '9:00 AM - 5:00 PM',                                           // 52
			wed: '9:00 AM - 5:00 PM',                                           // 53
			thu: '9:00 AM - 5:00 PM',                                           // 54
			fri: '9:00 AM - 5:00 PM',                                           // 55
			sat: '9:00 AM - 5:00 PM',                                           // 56
			sun: '9:00 AM - 5:00 PM'                                            // 57
		},                                                                   //
		streetAddress: '870 Halewili Rd',                                    // 59
		city: 'Kalaheo',                                                     // 60
		state: 'Hawaii',                                                     // 61
		zip: '96741',                                                        // 62
		description: 'Kauai coffee is one of our favorite tourist day activities.  First of all – it’s FREE!  Second, there’s COFFEE!  Can you sense the caffeine buzz?  Located on the south side of Kauai in Kalaheo, Kauai Coffee is the perfect stop on the way to Kokee.  There must be at least fifteen coffee types to sample – and they are great!',
		csimage: '/img/coffee-fruit.jpg',                                    // 64
		lat: '21.899872',                                                    // 65
		lng: '-159.560938'                                                   // 66
	});                                                                   //
	Cafes.insert({                                                        // 68
		name: 'Small Town Coffee Co.',                                       // 69
		placeid: 'ChIJNeHCRvLgBnwRrIKpQGUFsIg',                              // 70
		phone: '',                                                           // 71
		hours: {                                                             // 72
			mon: '6:00 AM - 4:00 PM',                                           // 73
			tue: '6:00 AM - 4:00 PM',                                           // 74
			wed: '6:00 AM - 4:00 PM',                                           // 75
			thu: '6:00 AM - 4:00 PM',                                           // 76
			fri: '6:00 AM - 4:00 PM',                                           // 77
			sat: '6:00 AM - 4:00 PM',                                           // 78
			sun: '6:00 AM - 4:00 PM'                                            // 79
		},                                                                   //
		streetAddress: '4-1543 Kuhio Hwy',                                   // 81
		city: 'Kapaa',                                                       // 82
		state: 'Hawaii',                                                     // 83
		zip: '96746',                                                        // 84
		description: 'Small Town’s atmosphere begs you to slow down, kick back, and sip on a cup of joe. It’s a great little coffee shop hidden in the Kauai craft fair at the north end of Kapaa town. Small Town’s coffee is consistently the most caffeinated cup on Kauai. Beware (and enjoy!)\n*Update – the coffee shop has relocated to a small bus not far from its original location.  Still good coffee – not quite the same atmosphere.  We recommend getting the coffee and walking across the street and drinking it at the beach ',
		csimage: '/img/small-town.jpg',                                      // 86
		lat: '22.079695',                                                    // 87
		lng: '-159.314549'                                                   // 88
	});                                                                   //
	Cafes.insert({                                                        // 90
		name: 'Art Cafe Hemingway',                                          // 91
		placeid: 'ChIJabHFQ_LgBnwROHHyufv_3m4',                              // 92
		phone: '(808) 822-2250',                                             // 93
		hours: {                                                             // 94
			mon: 'Closed',                                                      // 95
			tue: 'Closed',                                                      // 96
			wed: '8:00 AM - 2:00 PM, 6:00 - 9:00 PM',                           // 97
			thu: '8:00 AM - 2:00 PM, 6:00 - 9:00 PM',                           // 98
			fri: '8:00 AM - 2:00 PM, 6:00 - 9:00 PM',                           // 99
			sat: '8:00 AM - 2:00 PM, 6:00 - 9:00 PM',                           // 100
			sun: '8:00 AM - 2:00 PM, 6:00 - 9:00 PM'                            // 101
		},                                                                   //
		streetAddress: '4-1495 Kuhio Hwy',                                   // 103
		city: 'Kapaa',                                                       // 104
		state: 'Hawaii',                                                     // 105
		zip: '96746',                                                        // 106
		description: 'Cafe Hemingway is a savory piece of Europe, tucked on the north end of Kapaa town. I go there all time; so often that I don’t want to think about it too much because I don’t want to know how much I spend there every month! The atmosphere is classy and the service is relaxed, which is another way to say that you shouldn’t go there if you’re in a hurry. Grab a seat, relax, and enjoy the food prepared and drinks concocted by Markus and Jana, the culinary masterminds who own the place.',
		csimage: '/img/espresso.jpg',                                        // 108
		lat: '22.078464',                                                    // 109
		lng: '-159.315570'                                                   // 110
	});                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures.js.map
