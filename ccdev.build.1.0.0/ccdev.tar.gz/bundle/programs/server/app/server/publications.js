(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Publish Cafes collection                                            //
Meteor.publish('cafes', function () {                                  // 2
	return Cafes.find({}, { fields: {                                     // 3
			owner: false,                                                       // 4
			username: false                                                     // 5
		} });                                                                //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
