(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// router.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// ROUTER OPTIONS                                                      //
Router.configure({                                                     // 2
	layoutTemplate: 'layout',                                             // 3
	notFoundTemplate: 'notFound',                                         // 4
	loadingTemplate: 'loading',                                           // 5
	waitOn: function () {                                                 // 6
		return [Meteor.subscribe('cafes')];                                  // 7
	}                                                                     //
});                                                                    //
                                                                       //
// MAIN ROUTE: WELCOME                                                 //
//Router.route('/', function () {                                      //
//  name: 'coffeeshopList'                                             //
//});                                                                  //
                                                                       //
//  ROUTE: ABOUT                                                       //
Router.route('/about', {                                               // 19
	name: 'about'                                                         // 20
});                                                                    //
                                                                       //
// CRUD: CREATE COFFEESHOP                                             //
Router.route('/coffeeshop/create', {                                   // 24
	name: 'coffeeshopCreate'                                              // 25
});                                                                    //
                                                                       //
// CRUD: READ COFFEESHOP (SINGLE)                                      //
Router.route('/coffeeshop/view/:_id', {                                // 29
	name: 'coffeeshopView',                                               // 30
	data: function () {                                                   // 31
		var cafeData = Cafes.findOne({                                       // 32
			_id: this.params._id                                                // 34
		});                                                                  //
		return {                                                             // 37
			cafe: cafeData                                                      // 38
		};                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
// CRUD: READ COFFEESHOP LIST                                          //
Router.route('/', {                                                    // 44
	name: 'coffeeshopList',                                               // 45
	data: function () {                                                   // 46
		var cafeList = Cafes.find({                                          // 47
			_id: this.params._id                                                // 49
		});                                                                  //
		return {                                                             // 52
			cafe: cafeList                                                      // 53
		};                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
// CRUD: READ COFFEESHOP LIST (ADMIN)                                  //
Router.route('/admin', {                                               // 59
	name: 'admin',                                                        // 60
	data: function () {                                                   // 61
		var cafeList = Cafes.find({                                          // 62
			_id: this.params._id                                                // 64
		});                                                                  //
		return {                                                             // 67
			cafe: cafeList                                                      // 68
		};                                                                   //
	}                                                                     //
});                                                                    //
                                                                       //
// CRUD: UPDATE                                                        //
Router.route('/coffeeshop/update/:_id', {                              // 75
	name: 'coffeeshopUpdate',                                             // 76
	data: function () {                                                   // 77
		return Cafes.findOne({                                               // 78
			_id: this.params._id                                                // 80
		});                                                                  //
	}                                                                     //
                                                                       //
});                                                                    //
                                                                       //
// CRUD: DELETE COFFEESHOP                                             //
Router.route('/coffeeshop/delete/:_id', {                              // 89
	name: 'coffeeshopDelete',                                             // 90
	data: function () {                                                   // 91
		return Cafes.findOne({                                               // 92
			_id: this.params._id                                                // 94
		});                                                                  //
	}                                                                     //
                                                                       //
});                                                                    //
                                                                       //
// Before action hook to force login                                   //
var requireLogin = function () {                                       // 102
	if (!Meteor.user()) {                                                 // 103
		this.render('accessDenied');                                         // 104
	} else {                                                              //
		this.next();                                                         // 106
	}                                                                     //
};                                                                     //
                                                                       //
Router.onBeforeAction(requireLogin, { only: ['coffeeshopUpdate', 'admin'] });
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=router.js.map
